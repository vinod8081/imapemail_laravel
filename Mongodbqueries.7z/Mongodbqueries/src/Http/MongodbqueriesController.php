<?php

namespace Codebank\Mongodbqueries\Http;

use Codebank\Mongodbqueries\Mongodbqueries; //load model
use App\Http\Controllers\Controller;

class MongodbqueriesController extends Controller {

    public function __construct() {

    }

    public function getMongoQueries() {

        Mongodbqueries::getSampleQueries();
    }

}
