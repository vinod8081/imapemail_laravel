<?php

Route::get( 'mongo/', 'Codebank\Mongodbqueries\Http\MongodbqueriesController@getMongoQueries' );
