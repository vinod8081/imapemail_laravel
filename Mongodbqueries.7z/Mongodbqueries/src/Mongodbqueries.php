<?php

namespace Codebank\Mongodbqueries;

use Illuminate\Support\Facades\DB;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

/**
 * Description of JenssegersSampleQueries
 *
 * @author VPawar
 */
class Mongodbqueries extends Eloquent {

    protected $connection = 'mongodb';
    protected $collection = 'consumer_info_persona';

    /**
     * limit, in, and, or, order by, group by,like
     * https://github.com/jenssegers/laravel-mongodb
     * @param type $merchantId
     * @return type
     */
    public static function getSampleQueries() {


        $objCollection = DB::collection( 'consumer_info_persona' );

        //where and or where with limit and get only selected columns
        $response = $objCollection->where( 'consumer_id', '>', 100 )->orWhere( 'consumer_id', '<', 120 )->limit( 10 )->get( array( 'name_of_customer', 'consumer_id' ) );
        // And where
        //$response = $objCollection->where( 'consumer_id', '>', 100 )->Where( 'consumer_id', '<', 120 )->limit( 10 )->get( array( 'name_of_customer', 'consumer_id' ) );
        //$response = $objCollection->get( array( 'name_of_customer' ) );
        //Using Where In With An Array
        //$response = $objCollection->whereIn( 'consumer_email', ['nandadeep.potdar@gmail.com', 'ankit.anthwal@gmail.com', 'manu.rawat@gmail.com', 'mujibsayyad2223@gmail.com' ] )->get( array( 'name_of_customer', 'consumer_id' ) );
        //When using whereNotIn objects will be returned if the field is non existent. Combine with whereNotNull('age') to leave out those documents.
        //$response = $objCollection->whereNotNull( 'Link_Merchant_user_id' )->whereIn( 'consumer_email', ['nandadeep.potdar@gmail.com', 'ankit.anthwal@gmail.com', 'manu.rawat@gmail.com', 'mujibsayyad2223@gmail.com' ] )->get( array( 'name_of_customer', 'consumer_id' ) );
        // whereNull
        //$response = $objCollection->whereNull( 'Link_Merchant_user_id' )->whereIn( 'consumer_email', ['nandadeep.potdar@gmail.com', 'ankit.anthwal@gmail.com', 'manu.rawat@gmail.com', 'mujibsayyad2223@gmail.com' ] )->get( array( 'name_of_customer', 'consumer_id' ) );
        //order by and offset with limit
        //$response = $objCollection->skip( 1 )->take( 5 )->orderBy( 'name_of_customer', 'desc' )->get( array( 'name_of_customer', 'consumer_id' ) );
        //Distinct requires a field for which to return the distinct values.
        //$response = $objCollection->distinct()->get( ['name_of_customer' ] );
        // or
        // Limit or take can't apply with distinct
        //$response = $objCollection->distinct( 'name_of_customer' )->get();
        //Advanced Wheres
        /*
          $response = $objCollection->where( 'name_of_customer', 'like', '%het%' )->orWhere( function($query) {
          $query->Where( 'consumer_id', '>', 100 )->Where( 'consumer_id', '<', 120 );
          } )
          ->take( 4 )->get( ['name_of_customer' ] );
         */
        //Group By
        //$response = $objCollection->groupBy( 'name_of_customer' )->take( 3 )->get( ['name_of_customer' ] );
        //Aggregation
        ///Aggregations are only available for MongoDB versions greater than 2.2 .
        /*
          $total    = $objCollection->count();
          $response = $objCollection->max( 'consumer_created' );
          $response = $objCollection->min( 'consumer_created' );
          $response = $objCollection->avg( 'consumer_created' );
         */
        //$total = $objCollection->sum( 'count_merchant' );
        //******************************Incrementing or decrementing a value of a column************************************
        //Perform increments or decrements (default 1) on specified attributes:
        /*
          print_r( $objCollection->where( 'consumer_id', 1 )->get( array( 'count_merchant' ) ) );
          echo "<br/>";
          print_r( $objCollection->where( 'consumer_id', 1 )->increment( 'count_merchant' ) );
          echo "<br/>";
          print_r( $objCollection->where( 'consumer_id', 1 )->get( array( 'count_merchant' ) ) );
          echo "<br/>";

          //$objCollection->where( 'consumer_id', 1 )->decrement( 'count_merchant', 2 );

          echo "<br/>";
          print_r( $objCollection->where( 'consumer_id', 1 )->get( array( 'count_merchant' ) ) );

          //The number of updated objects is returned:
          //echo $count = $objCollection->increment( 'count_merchant' );
          echo "<br/>";
          //You may also specify additional columns to update:

          $objCollection->where( 'age', '29' )->increment( 'age', 1, ['group' => 'thi' ] );
          $objCollection->where( 'bmi', 30 )->decrement( 'bmi', 1, ['category' => 'overweight' ] );

         */
        //******************************Incrementing or decrementing a value of a column************************************
        //Regex
        //$response = $objCollection->where( 'name_of_customer', 'regexp', '/.*doe/i' )->take( 3 )->get();
        //$response = $objCollection->where( 'name_of_customer', 'not regexp', '/.*doe/i' )->take( 3 )->get();
        //Type
        //Selects documents if a field is of the specified type. For more information check:
        //https://docs.mongodb.org/manual/reference/operator/query/type/#op._S_type
        //$response = $objCollection->where( 'count_merchant', 'type', 16 )->take( 2 )->get();
        //Mod
        //Performs a modulo operation on the value of a field and selects documents with a specified result .
        //$response = $objCollection->where( 'count_merchant', 'mod', [2, 0 ] )->take( 4 )->orderBy( 'count_merchant', 'desc' )->get( array( 'count_merchant' ) );


        echo "<pre>";
        print_r( $response );
        die;
    }

}
