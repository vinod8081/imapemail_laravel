<ul>
@foreach ($folders as $folder)

<li>{{$folder}}
</li>
@endforeach
</ul>